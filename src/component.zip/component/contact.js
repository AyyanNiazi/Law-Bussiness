import React,{Component} from 'react';
import './main.css';



class Contact extends Component {
    constructor(props) {
        super(props);
    
       
        
    }

  

  
    render() { 
        return ( 
          <div className=''>
              Contact
          </div>
        );
    }
}



export default Contact